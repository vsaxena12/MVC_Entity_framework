﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace LeaveManagement.Models
{
    public class Leave
    {
        [Key]
        [Required]
        public int LeaveID { get; set; }


        [Required]
        public int UserID { get; set; }

        [Required]
        public int LeaveTypeID { get; set; }


        [Required]
        public int Noofdays { get; set; }

        [Required]
        public string LeaveReason { get; set; }

        [Required]
        public string LeaveStatus { get; set; }

    }
}
